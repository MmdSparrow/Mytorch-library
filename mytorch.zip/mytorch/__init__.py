from mytorch.tensor import Tensor, Dependency
from mytorch.model import Model