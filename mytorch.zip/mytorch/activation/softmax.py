import numpy as np
from mytorch import Tensor, Dependency


def softmax(x: Tensor) -> Tensor:
    """
    TODO: implement softmax function
    hint: you can do it using function you've implemented (not directly define grad func)
    hint: you can't use sum because it has not axis argument so there are 2 ways:
        1. implement sum by axis
        2. using matrix mul to do it :) (recommended)
    hint: a/b = a*(b^-1)
    """
    # x.round(70)
    exp = x.exp()
    if np.isinf(exp.data).any():
        # raise ValueError("overflow in softmax!")
        exp=exp.replace_infinity_with_max()
    denominator = exp.__matmul__(Tensor(np.ones((exp.shape[-1], 1))))
    if np.isinf(denominator.data).any():
        denominator=denominator.replace_infinity_with_max()
    result = exp.__mul__(denominator.__pow__(-1))
    if np.isinf(result.data).any():
        result=result.replace_infinity_with_max()
    return result
