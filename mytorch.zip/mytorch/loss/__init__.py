from mytorch.loss.ce import CategoricalCrossEntropy
from mytorch.loss.mse import MeanSquaredError
