"this code is inspired by https://github.com/amirrezarajabi/rs-dl-framework/blob/main/rsdl/tensors.py"

import numpy as np
from typing import List, NamedTuple, Callable, Optional, Union

class Dependency(NamedTuple):
    tensor: 'Tensor'
    grad_fn: Callable[[np.ndarray], np.ndarray]

Arrayable = Union[float, list, np.ndarray]

def ensure_array(arrayable: Arrayable) -> np.ndarray:
    if isinstance(arrayable, np.ndarray):
        return arrayable
    else:
        return np.array(arrayable)

Tensorable = Union[float, 'Tensor', np.ndarray]

def ensure_tensor(tensorable: Tensorable) -> 'Tensor':
    if isinstance(tensorable, Tensor):
        return tensorable
    else:
        return Tensor(tensorable)

class Tensor:

    def __init__(
            self,
            data: np.ndarray,
            requires_grad: bool = False,
            depends_on: List[Dependency] = None) -> None:
        """
        Args:
            data: value of tensor (numpy.ndarray)
            requires_grad: if tensor needs grad (bool)
            depends_on: list of dependencies
        """

        self._data = ensure_array(data)
        self.requires_grad = requires_grad
        self.depends_on = depends_on

        if not depends_on:
            self.depends_on = []

        self.shape = self._data.shape
        self.grad: Optional['Tensor'] = None

        if self.requires_grad:
            self.zero_grad()

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, new_data: np.ndarray) -> None:
        self._data = new_data
        self.shape = new_data.shape
        self.grad = None

    def zero_grad(self) -> None:
        self.grad = Tensor(np.zeros_like(self.data, dtype=np.float64))

    def __repr__(self) -> str:
        return f"Tensor({self.data}, requires_grad={self.requires_grad})"

    def sum(self) -> 'Tensor':
        return _tensor_sum(self)

    def log(self, base=10) -> 'Tensor':
        return _tensor_log(self, base)

    def exp(self) -> 'Tensor':
        return _tensor_exp(self)

    def round(self, base=100) -> 'Tensor':
        return _tensor_round(self, base)
    
    def mean(self) -> 'Tensor':
        return _tensor_mean(self)
    
    def max(self) -> 'Tensor':
        return _tensor_max(self)
    
    def replace_zero_with_min(self) -> 'Tensor':
        return _tensor_replace_zero_with_min(self)
    
    def replace_infinity_with_max(self) -> 'Tensor':
        return _tensor_replace_infinity_with_max(self)

    def zero_padding(self, padding_size=(1,1)) -> 'Tensor':
        return _tensor_zero_padding(self, padding_size)
    
    def __add__(self, other) -> 'Tensor':
        return _add(self, ensure_tensor(other))

    def __radd__(self, other) -> 'Tensor':
        return _add(ensure_tensor(other), self)

    def __iadd__(self, other) -> 'Tensor':
        res_tensor = _add(self, ensure_tensor(other))
        self._data = res_tensor._data
        self.requires_grad = res_tensor.requires_grad
        self.depends_on = res_tensor.depends_on
        return self

    def __sub__(self, other) -> 'Tensor':
        return _sub(self, ensure_tensor(other))

    def __rsub__(self, other) -> 'Tensor':
        return _sub(ensure_tensor(other), self)

    def __isub__(self, other) -> 'Tensor':
        res_tensor = _sub(self, ensure_tensor(other))
        self._data = res_tensor._data
        self.requires_grad = res_tensor.requires_grad
        self.depends_on = res_tensor.depends_on
        return self

    def __mul__(self, other) -> 'Tensor':
        return _mul(self, ensure_tensor(other))

    def __rmul__(self, other) -> 'Tensor':
        return _mul(ensure_tensor(other), self)

    def __imul__(self, other) -> 'Tensor':
        res_tensor = _mul(self, ensure_tensor(other))
        self._data = res_tensor._data
        self.requires_grad = res_tensor.requires_grad
        self.depends_on = res_tensor.depends_on
        return self

    def __matmul__(self, other) -> 'Tensor':
        return _matmul(self, ensure_tensor(other))

    def __pow__(self, power: float) -> 'Tensor':
        return _tensor_pow(self, power)

    def __getitem__(self, idcs) -> 'Tensor':
        # idcs indicates [:], used to get slice of items
        return _tensor_slice(self, idcs)
    
    def __setitem__(self, idcs, other):
        "TODO: handle tensor item assignment."
        res_tensor = ensure_tensor(other)
        self._data[idcs] = res_tensor._data
        self.requires_grad = res_tensor.requires_grad
        # self.depends_on = res_tensor.depends_on
        if self.grad is not None and self.requires_grad and other.requires_grad:
            self.grad.data[idcs] = res_tensor.grad.data
        #     def grad_fn(grad: np.ndarray):
        #         pass
        #         #
        #     self.depends_on = [Dependency(self, grad_fn)]
            
        # else:
        #     self.depends_on = []
        if self.depends_on is not None:
            self.depends_on = self.depends_on.append(res_tensor.depends_on)


    def __neg__(self) -> 'Tensor':
        return _tensor_neg(self)
    
    # def __sqrt__(self) -> 'Tensor':
    #     return _tensor_sqrt(self)

    def backward(self, grad: 'Tensor' = None) -> None:
        if grad is None:
            if self.shape == ():
                grad = Tensor(1.0)
            else:
                raise RuntimeError("grad must be specified for non-0-tensor")
        self.grad.data = self.grad.data + grad.data
        for dependency in self.depends_on:
            backward_grad = dependency.grad_fn(grad.data)
            dependency.tensor.backward(Tensor(backward_grad))

"""
TODO: handle tensor calculations through these methods.
hint: do not change t.data but create a new Tensor if required. 
grad_fn handles required gradient calculation for current operation.
you can check _tensor_sum(), _add() and _mul() as reference.
"""

def _tensor_sum(t: Tensor) -> Tensor:
    data = t.data.sum()
    req_grad = t.requires_grad

    if req_grad:
        def grad_fn(grad: np.ndarray):
            return grad * np.ones_like(t.data)

        depends_on = [Dependency(t, grad_fn)]

    else:
        depends_on = []

    return Tensor(data=data, requires_grad=req_grad, depends_on=depends_on)

def _tensor_log(t: Tensor, base) -> Tensor:
    "TODO: tensor log"
    data = np.log(t.data)/np.log(base)
    req_grad = t.requires_grad

    if req_grad:
        def grad_fn(grad: np.ndarray):
            return grad / (t.data * np.log(base))

        depends_on = [Dependency(t, grad_fn)]

    else:
        depends_on = []

    return Tensor(data=data, requires_grad=req_grad, depends_on=depends_on)

def _tensor_exp(t: Tensor) -> Tensor:
    "TODO: tensor exp"
    data = np.exp(t.data)
    req_grad = t.requires_grad

    if req_grad:
        def grad_fn(grad: np.ndarray):
            return grad * np.exp(t.data)

        depends_on = [Dependency(t, grad_fn)]

    else:
        depends_on = []

    return Tensor(data=data, requires_grad=req_grad, depends_on=depends_on)

def _tensor_pow(t: Tensor, power: float) -> Tensor:
    "TODO: tensor power"
    data = np.power(t.data, power)
    req_grad = t.requires_grad

    if req_grad:
        def grad_fn(grad: np.ndarray):
            return grad * power * np.power(t.data, power - 1)

        depends_on = [Dependency(t, grad_fn)]

    else:
        depends_on = []

    return Tensor(data=data, requires_grad=req_grad, depends_on=depends_on)

def _tensor_slice(t: Tensor, idcs) -> Tensor:
    "TODO: tensor slice"
    if t.data.ndim == 0:
        raise ValueError("Erorrrrrrrrrrrr...............")
        # data = t.data
        # requires_grad = t.requires_grad

        # if requires_grad:
        #     def grad_fn(grad: np.ndarray) -> np.ndarray:
        #         return grad

        #     depends_on = Dependency(t, grad_fn)
        # else:
        #     depends_on = []

        # return Tensor(data, requires_grad, depends_on)
    else:
        data = t.data[idcs]
        requires_grad = t.requires_grad

        if requires_grad:
            def grad_fn(grad: np.ndarray) -> np.ndarray:
                bigger_grad = np.zeros_like(data)
                bigger_grad[idcs] = grad
                return bigger_grad

            depends_on = Dependency(t, grad_fn)
        else:
            depends_on = []

        return Tensor(data, requires_grad, depends_on)

def _tensor_neg(t: Tensor) -> Tensor:
    "TODO: tensor negative"
    data = np.negative(t.data)
    requires_grad = t.requires_grad
    if requires_grad:
        depends_on = [Dependency(t, lambda x: -x)]
    else:
        depends_on = []

    return Tensor(data, requires_grad, depends_on)

def _add(t1: Tensor, t2: Tensor) -> Tensor:
    data = t1.data + t2.data
    req_grad = t1.requires_grad or t2.requires_grad
    depends_on: List[Dependency] = []

    if t1.requires_grad:
        def grad_fn1(grad: np.ndarray) -> np.ndarray:
            ndims_added = grad.ndim - t1.data.ndim
            for _ in range(ndims_added):
                grad = grad.sum(axis=0)
            for i, dim in enumerate(t1.shape):
                if dim == 1:
                    grad = grad.sum(axis=i, keepdims=True)
            return grad

        depends_on.append(Dependency(t1, grad_fn1))

    if t2.requires_grad:
        def grad_fn2(grad: np.ndarray) -> np.ndarray:
            ndims_added = grad.ndim - t2.data.ndim
            for _ in range(ndims_added):
                grad = grad.sum(axis=0)
            for i, dim in enumerate(t2.shape):
                if dim == 1:
                    grad = grad.sum(axis=i, keepdims=True)
            return grad

        depends_on.append(Dependency(t2, grad_fn2))

    return Tensor(
        data=data,
        requires_grad=req_grad,
        depends_on=depends_on
    )


def _sub(t1: Tensor, t2: Tensor) -> Tensor:
    "TODO: implement sub"
    # Hint: a-b = a+(-b)
    return _add(t1, _tensor_neg(t2))

def _mul(t1: Tensor, t2: Tensor) -> Tensor:
    # Done ( Don't change )
    data = t1.data * t2.data
    req_grad = t1.requires_grad or t2.requires_grad
    depends_on: List[Dependency] = []

    if t1.requires_grad:
        def grad_fn1(grad: np.ndarray) -> np.ndarray:
            grad = grad * t2.data
            ndims_added = grad.ndim - t1.data.ndim
            for _ in range(ndims_added):
                grad = grad.sum(axis=0)
            for i, dim in enumerate(t1.shape):
                if dim == 1:
                    grad = grad.sum(axis=i, keepdims=True)
            return grad

        depends_on.append(Dependency(t1, grad_fn1))
    if t2.requires_grad:
        def grad_fn2(grad: np.ndarray) -> np.ndarray:
            grad = grad * t1.data
            ndims_added = grad.ndim - t2.data.ndim
            for _ in range(ndims_added):
                grad = grad.sum(axis=0)
            for i, dim in enumerate(t2.shape):
                if dim == 1:
                    grad = grad.sum(axis=i, keepdims=True)
            return grad

        depends_on.append(Dependency(t2, grad_fn2))

    return Tensor(
        data=data,
        requires_grad=req_grad,
        depends_on=depends_on
    )

def _matmul(t1: Tensor, t2: Tensor) -> Tensor:
    "TODO: implement matrix multiplication"
    data = t1.data @ t2.data
    requires_grad = t1.requires_grad or t2.requires_grad

    depends_on: List[Dependency] = []

    if t1.requires_grad:
        def grad_fn1(grad: np.ndarray) -> np.ndarray:
            return grad @ t2.data.T

        depends_on.append(Dependency(t1, grad_fn1))

    if t2.requires_grad:
        def grad_fn2(grad: np.ndarray) -> np.ndarray:
            return t1.data.T @ grad

        depends_on.append(Dependency(t2, grad_fn2))

    return Tensor(data,
                  requires_grad,
                  depends_on)

# def _tensor_sqrt(t: Tensor) -> Tensor:
#     data = np.sqrt(t.data)
#     req_grad = t.requires_grad

#     if req_grad:
#         def grad_fn(grad: np.ndarray):
#             return grad * 1/2 * np.power(t.data, power - 1)

#         depends_on = [Dependency(t, grad_fn)]

#     else:
#         depends_on = []

#     return Tensor(data=data, requires_grad=req_grad, depends_on=depends_on)


def _tensor_round(t: Tensor, base):
    data = np.round(t.data, base)
    req_grad = t.requires_grad

    if req_grad:
        def grad_fn(grad: np.ndarray):
            return grad

        depends_on = [Dependency(t, grad_fn)]

    else:
        depends_on = []

    return Tensor(data=data, requires_grad=req_grad, depends_on=depends_on)



def _tensor_mean(t: Tensor):
    data = np.mean(t.data)
    req_grad = t.requires_grad

    if req_grad:
        def grad_fn(grad: np.ndarray):
            return grad # * 1/(self.kernel_size[0]*self.kernel_size[1])

        depends_on = [Dependency(t, grad_fn)]

    else:
        depends_on = []

    return Tensor(data=data, requires_grad=req_grad, depends_on=depends_on)


def _tensor_max(t: Tensor):
    data = np.max(t.data)
    req_grad = t.requires_grad

    if req_grad:
        def grad_fn(grad: np.ndarray):
            return grad

        depends_on = [Dependency(t, grad_fn)]

    else:
        depends_on = []

    return Tensor(data=data, requires_grad=req_grad, depends_on=depends_on)



def _tensor_replace_zero_with_min(t: Tensor):
    min_positive = (np.min(t.data[t.data > 0]))/10
    data = np.where(t.data == 0, min_positive, t.data)

    req_grad = t.requires_grad

    if req_grad:
        def grad_fn(grad: np.ndarray):
            return grad

        depends_on = [Dependency(t, grad_fn)]

    else:
        depends_on = []

    return Tensor(data=data, requires_grad=req_grad, depends_on=depends_on)



def _tensor_replace_infinity_with_max(t: Tensor):
    LARGE_NUMBER = np.finfo(np.float64).max
    data = np.nan_to_num(t.data, nan=0, posinf=LARGE_NUMBER, neginf=-LARGE_NUMBER)
    req_grad = t.requires_grad

    if req_grad:
        def grad_fn(grad: np.ndarray):
            return grad

        depends_on = [Dependency(t, grad_fn)]

    else:
        depends_on = []

    return Tensor(data=data, requires_grad=req_grad, depends_on=depends_on)

def _tensor_zero_padding(t: Tensor, padding_size):
    
    def zero_padding(x, padding_size=(1,1)):
        data= np.pad(x, padding_size, mode='constant', constant_values=0)
        return data
    
    batch_data= []
    for batch in t.data:
        channel_data = []
        for channel in batch:
            channel_data.append(zero_padding(channel, padding_size))
        batch_data.append(channel_data)
    data= batch_data
    req_grad = t.requires_grad

    if req_grad:
        def grad_fn(grad: np.ndarray):
            return grad

        depends_on = [Dependency(t, grad_fn)]

    else:
        depends_on = []

    return Tensor(data=data, requires_grad=req_grad, depends_on=depends_on)